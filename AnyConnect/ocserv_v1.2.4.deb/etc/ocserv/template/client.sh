#!/bin/bash

command -v openssl >>/dev/null 2>&1
[ $? -ne 0 ] && echo "Not Found 'openssl'" && exit 1
cd `dirname "$0"`

export OrgName
export GroupName
export PASSWORD
export INIT
export BLANK=" "


while [[ $# -ge 1 ]]; do
  case $1 in
    -o)
      shift
      OrgName=`echo "$1" |sed 's/\s//g'`
      shift
      ;;
    -g)
      shift
      GroupName=`echo "$1" |sed 's/\s//g'`
      shift
      ;;
    -p)
      shift
      PASSWORD=`echo "$1" |sed 's/\s//g'`
      shift
      ;;
    -i)
      shift
      INI_=`echo $1 |sed 's/\s//g'`
      INIT="${INI_:-0.0.0.0}"
      shift
      ;;
    *)
      echo -e "Usage:\n\tbash $0 -o <OrgName> -g <GroupName> -p <PASSWORD> -i <CN>\n"
      exit 1;
      ;;
  esac
done


[ -n "$INIT" ] && [ -f "./ca.crt.pem" ] && [ -n "${OrgName}" ] && rm -rf "./ca.crt.pem"
[ "$BLANK" == " " ] && [ -f "$HOME/.rnd" ] || openssl rand -writerand "$HOME/.rnd"
[ -f "./ca.crt.pem" ] && OrgName=`openssl x509 -noout -in "./ca.crt.pem" -subject 2>/dev/null |sed 's/.*\s*O\s\+=\s\+\([^,\ ]\+\),.*/\1/'`

[ -n "${OrgName}" ] || OrgName="MoeClub"
[ -n "${GroupName}" ] || GroupName="Default"


if [ ! -f ./ca.crt.pem -o ! -f ./ca.key.pem ] || [ -n "$INIT" ] ; then
  openssl req -x509 -sha256 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -days 3650 -subj "/C=${BLANK}${BLANK}/ST=${BLANK}/L=${BLANK}/OU=${BLANK}/O=${OrgName}/CN=${OrgName} CA" -addext "keyUsage=critical, keyCertSign, cRLSign" -rand /dev/urandom -outform PEM -keyout "./ca.key.pem" -out "./ca.crt.pem"  >/dev/null 2>&1

  [ $? -ne 0 ] && echo "Generating CA Fail" && exit 1
  cp -rf ./ca.crt.pem ../ca.crt.pem
 
  openssl req -x509 -sha256 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -days 3650 -subj "/C=${BLANK}${BLANK}/ST=${BLANK}/L=${BLANK}/OU=${BLANK}/O=${BLANK}/CN=${INIT:-0.0.0.0}" -config <(echo -e "[ req ]\ndistinguished_name=req\n") -addext "basicConstraints=CA:FALSE" -addext "keyUsage=critical, digitalSignature, keyEncipherment" -addext "extendedKeyUsage=serverAuth, clientAuth" -rand /dev/urandom -outform PEM -keyout "../server.key.pem" -out "../server.crt.pem" >/dev/null 2>&1
  [ $? -ne 0 ] && echo "Generating Server Cert Fail" && exit 1
  
  chmod 755 ../ca.crt.pem ../server.key.pem ../server.crt.pem
fi

if [ -n "$INIT" ]; then
  exit 0
fi


openssl req -new -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -subj "/C=${BLANK}${BLANK}/ST=${BLANK}/L=${BLANK}/OU=${GroupName}/O=${OrgName}/CN=${OrgName}.${GroupName}" -rand /dev/urandom -outform PEM -keyout "./user.key.pem" -out "./user.csr.pem" >/dev/null 2>&1
[ $? -ne 0 ] && echo "Generating CSR Fail" && exit 1

openssl x509 -set_serial `printf "%04d" "$(($RANDOM % 10000))"` -CAform PEM -CA "./ca.crt.pem" -CAkey "./ca.key.pem" -req -sha256 -days 365 -in "./user.csr.pem" -outform PEM -out "./user.crt.pem" -extfile <(echo -e "basicConstraints=CA:FALSE\nkeyUsage=digitalSignature\nextendedKeyUsage=clientAuth\nsubjectKeyIdentifier=hash\nauthorityKeyIdentifier=keyid\n")
[ $? -ne 0 ] && echo "Generating Cert Fail" && exit 1


cat ./ca.crt.pem >>./user.crt.pem
openssl pkcs12 --help 2>&1 |grep -q 'legacy' && legacy="-legacy" || legacy=""
openssl pkcs12 $legacy -export -inkey "./user.key.pem" -in "./user.crt.pem" -name "${OrgName}.${GroupName}" -certfile "./ca.crt.pem" -caname "${OrgName} CA" -out "./${GroupName}.p12" -passout "pass:$PASSWORD"

[ $? -eq '0' ] && echo -e "\nSuccess! \nGROUP\t\tPASSWORD\n${GroupName}\t\t$PASSWORD\n" || echo -e "\nFail! \n";
rm -rf ./user.csr.pem ./user.key.pem ./user.crt.pem
# openssl x509 -noout -text -in ./ca.crt.pem

exit 0
